//
//  RotatedBadgeSymbol.swift
//  Landmarks
//
//  Created by IACD Training 4 on 2024/04/15.
//

import SwiftUI

struct RotatedBadgeSymbol: View {
    let angle: Angle

    var body: some View {
        BadgeSymbol()
            .padding(-60)
            .rotationEffect(angle, anchor: .bottom)

    }
}

#Preview {
    RotatedBadgeSymbol(angle: Angle(degrees: 5))
}
